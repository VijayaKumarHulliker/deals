package com.example.dealsdraytest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
